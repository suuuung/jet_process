import numpy as np
import torch
import cv2
from model import VGG16
from torchvision import transforms
from torch.autograd import Variable
from torch import nn
from PIL import Image
def center_crop(frame):
    frame = frame[8:120, 30:142, :]
    return np.array(frame).astype(np.uint8)


def inference():
    # 定义模型训练的设备
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    data_transform = transforms.Compose(
        [transforms.Resize((224, 224)),
         transforms.ToTensor()])
    # 加载数据集标签
    with open('D:\zxl\c3d\data\labels.txt', 'r') as f :
        class_names = f.readlines()
        # print(class_names)
        f.close()

    # 加载模型，并将模型参数加载到模型中
    model = VGG16()
    # checkpoint = torch.load(r'D:\SUNYUE\VGG16\best_model.pth')
    # model.load_state_dict(checkpoint['state_dict'])
    model.load_state_dict(torch.load('D:/SUNYUE/VGG16/best_model.pth'))

    # 将模型放入到设备中，并设置验证式
    model.to(device)
    model.eval()

    video = r"D:\zxl\jet_video\88\m_0_75_88_0_2_4_2.mp4"

    cap = cv2.VideoCapture(video)
    retaining = True

    # clip = []
    while retaining:
        retaining, frame = cap.read() # 读取视频帧
        if not retaining and frame is None:
            continue

        # tmp_ = cv2.resize(frame, (224, 224))
        # tmp = tmp_ - np.array([[[90.0, 98.0, 102.0]]])
        # clip.append(tmp)

        #
        # inputs = np.array(tmp_).astype(np.float32)
        # # inputs = np.expand_dims(inputs, axis=0)
        # inputs = np.transpose(inputs, (2, 1, 0))
        # inputs = torch.from_numpy(inputs)
        # inputs = torch.autograd.Variable(inputs, requires_grad=False).to(device)
        img = Image.fromarray(frame)  # 这里ndarray_image为原来的numpy数组类型的输入
        img = data_transform(img)
        # expand batch dimension
        img = torch.unsqueeze(img, dim=0)
        with torch.no_grad():
            output = torch.squeeze(model(img.to(device))).cpu()
            predict = torch.softmax(output, dim=0)
            predict_cla = torch.argmax(predict).numpy()
            # outputs = model.forward(inputs)
        print(class_names[predict_cla])
        cv2.putText(frame, class_names[predict_cla].split(' ')[-1].strip(), (20, 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.5,
                    (0, 0, 255), 1)

        # cv2.putText(frame, "prob: %.4f" % predict_cla, (20, 40),
        #             cv2.FONT_HERSHEY_SIMPLEX, 1.5,
        #             (0, 0, 255), 1)
        # print(class_names[label].split(' ')[-1].strip())
        # print("prob: %.4f" % probs[0][label])


        cv2.namedWindow('result', cv2.WINDOW_NORMAL)
        cv2.resizeWindow('result', 800, 600)
        cv2.imshow('result', frame)
        cv2.waitKey(30)

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    inference()