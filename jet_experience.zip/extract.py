import os
import shutil


def extract_images_to_current_directory():
    # 获取当前工作目录
    current_dir = os.getcwd()
    current_dir = r"D:\SUNYUE\VGG16\data\jet_video\95"
    # 定义支持的图片格式
    image_extensions = ('.jpg', '.jpeg', '.png', '.gif', '.bmp')
重来yic
    # 遍历当前目录及其子目录
    for root, dirs, files in os.walk(current_dir):
        for file in files:
            # 检查文件扩展名是否为支持的图片格式
            if file.lower().endswith(image_extensions):
                # 构造源文件路径
                source_file = os.path.join(root, file)
                # 构造目标文件路径
                target_file = os.path.join(current_dir, file)

                # 如果目标文件已经存在，添加后缀以避免覆盖
                if os.path.exists(target_file):
                    base, extension = os.path.splitext(file)
                    counter = 1
                    # 添加后缀直到找到一个不存在的文件名
                    while os.path.exists(target_file):
                        target_file = os.path.join(current_dir, f"{base}_{counter}{extension}")
                        counter += 1

                # 复制文件到当前目录
                shutil.copy(source_file, target_file)
                print(f"复制文件: {source_file} 到 {target_file}")


if __name__ == "__main__":
    extract_images_to_current_directory()
