import cv2
import os
import random


def extract_random_frame(video_path, start_time, end_time):
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    start_frame = int(start_time * fps)
    end_frame = min(int(end_time * fps), total_frames - 1)

    if start_frame >= end_frame:
        print(f"Video too short: {video_path}")
        return None

    random_frame_number = random.randint(start_frame, end_frame)
    cap.set(cv2.CAP_PROP_POS_FRAMES, random_frame_number)

    ret, frame = cap.read()
    cap.release()

    return frame if ret else None

#
# def process_videos_in_folder(folder_path, output_base_path):
#     for filename in os.listdir(folder_path):
#         if filename.endswith(('.mp4', '.avi', '.mov', '.mkv')):  # 只处理视频文件
#             video_path = os.path.join(folder_path, filename)
#             video_name, _ = os.path.splitext(filename)
#             output_folder = os.path.join(output_base_path, video_name)
#
#             # 创建输出文件夹
#             os.makedirs(output_folder, exist_ok=True)
#
#             # 抽取前 0.5 秒内的随机帧
#             start_frame = extract_random_frame(video_path, 0, 0.5)
#             if start_frame is not None:
#                 start_frame_path = os.path.join(output_folder, f"{video_name}_start.jpg")
#                 cv2.imwrite(start_frame_path, start_frame)
#
#             # 获取视频总时长（秒）
#             cap = cv2.VideoCapture(video_path)
#             duration = cap.get(cv2.CAP_PROP_FRAME_COUNT) / cap.get(cv2.CAP_PROP_FPS)
#             cap.release()
#
#             # 抽取最后 0.5 秒内的随机帧
#             end_frame = extract_random_frame(video_path, max(0, duration - 0.5), duration)
#             if end_frame is not None:
#                 end_frame_path = os.path.join(output_folder, f"{video_name}_end.jpg")
#                 cv2.imwrite(end_frame_path, end_frame)
#
#     print("所有视频处理完成，帧已成功保存。")



def process_videos_in_folder(folder_path, output_base_path):
    for filedir in os.listdir(folder_path):
        for filename in os.listdir(os.path.join(folder_path,filedir)):
            if filename.endswith(('.mp4', '.avi', '.mov', '.mkv')):  # 只处理视频文件
                video_path = os.path.join(folder_path,filedir, filename)
                video_name, _ = os.path.splitext(filename)
                output_folder = os.path.join(output_base_path,filedir, video_name)

                # 创建输出文件夹
                os.makedirs(output_folder, exist_ok=True)

                # 抽取前 0.5 秒内的随机帧
                start_frame = extract_random_frame(video_path, 0, 5)
                if start_frame is not None:
                    start_frame_path = os.path.join(output_folder, f"{video_name}_start.jpg")
                    cv2.imwrite(start_frame_path, start_frame)

                # 获取视频总时长（秒）
                cap = cv2.VideoCapture(video_path)
                duration = cap.get(cv2.CAP_PROP_FRAME_COUNT) / cap.get(cv2.CAP_PROP_FPS)
                cap.release()

                # 抽取最后 0.5 秒内的随机帧
                end_frame = extract_random_frame(video_path, max(0, duration - 0.5), duration)
                if end_frame is not None:
                    end_frame_path = os.path.join(output_folder, f"{video_name}_end.jpg")
                    cv2.imwrite(end_frame_path, end_frame)

    print("所有视频处理完成，帧已成功保存。")


# 使用示例
folder_path = r'D:\SUNYUE\VGG16\data\jet_video_1'
output_base_path = 'D:\SUNYUE\VGG16\data\jet_video_2'
process_videos_in_folder(folder_path,output_base_path)#你要单独输出
